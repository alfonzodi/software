package multicast

import "github.com/pkg/errors"

// Errors
var (
	ErrInvalidFCnt = errors.New("invalid frame-counter value")
)
