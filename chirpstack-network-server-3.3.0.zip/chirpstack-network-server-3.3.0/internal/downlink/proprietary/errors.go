package proprietary

import "errors"

// errors
var (
	ErrInvalidDataRate = errors.New("invalid data-rate")
)
