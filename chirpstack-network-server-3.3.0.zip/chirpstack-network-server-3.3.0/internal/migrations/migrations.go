//go:generate go-bindata -pkg migrations -o migrations_gen.go -prefix ../../migrations/ ../../migrations/
package migrations
