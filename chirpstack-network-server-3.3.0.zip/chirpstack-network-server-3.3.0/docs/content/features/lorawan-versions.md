---
title: LoRaWAN versions
menu:
    main:
        parent: features
        weight: 2
description: LoRa Server supports LoRaWAN 1.0 and LoRaWAN 1.1 devices simultaniously.
---

# Supported LoRaWAN versions

LoRa Server supports both LoRaWAN 1.0 and LoRaWAN 1.1 devices simultaniously.
In the [Device-profile]({{<relref "device-profile.md">}}) you can define the
implemented LoRaWAN version for the devices assigned to the given
device-profile.
