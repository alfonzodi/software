---
title: Install
menu:
    main:
        parent: install
        weight: 1
hidden: true
---

# LoRa Server installation
