//go:generate protoc -I=. -I=../.. --go_out=paths=source_relative:. gw.proto

package gw
